#include <stdio.h>


int main()
{
    printf("This is your first challenge. Let's get some bread for free!\n");
    getchar();
    puts((char*)(1));
}
